<?php include "verificarFormMedicamento.php"?>

<!doctype html>

<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro de Pacientes - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<title>Cadastro de Pacientes - Lar Santo Antônio</title>
    <!-- Bootstrap -->
		<link href="../css/bootstrap.css" rel="stylesheet">
	</head>

	<body>
				<?php include "menu.php"?>

	  
		<header> <!-- Deixa o fundo cinza -->
			<div class="jumbotron">
				<div class="container">
					<div class="row"> <!-- Cria uma linha -->
						<div class="col-12"> <!-- Espaçamento de colunas -->
							<h1 class="text-center">Cadastro de Medicamentos</h1>
						</div>
					</div>  
				</div>
			</div>
		</header>

<body>
	<div class="container">
			<form method="post" name="frmMedicamento" action="" onchange="this.form.submit();">
				<select name="paciente" class="form-control">
					<option value="">Selecione:</option>
				<?php
				$result = mysqli_query($con,"SELECT pac_id, pac_nome, pac_sobrenome FROM paciente order by pac_nome;");
				while($row = mysqli_fetch_array($result))
				{
					echo "<option value=". $row['pac_id'] .">". $row['pac_nome'] ." ". $row['pac_sobrenome']."</option>";
				}
				?>
				</select>
				<div class="row">
					<div class="form-group col">
						<p>Nome do medicamento:</p>
						<input class="form-control" type="text" name="medNome" value="<?php if(isset($_POST['medNome'])) echo $_POST['medNome']?>"/>
					</div>
					<div class="form-group col">
						<p>Dosagem do medicamento:</p>
						<input class="form-control" type="text" name="medDosagem" value="<?php if(isset($_POST['medDosagem'])) echo $_POST['medDosagem']?>"/>
					</div>
				</div>	
				<div class="row">
					<div class="form-group col">
						<p>Começou a tomar o medicamento dia:</p>
						<input class="form-control" type="date" name="medIniDate" value=""/>
					</div>
					<div class="form-group col">
						<p>Tomar o medicamento até o dia:</p>
						<input class="form-control" type="date" name="medFimDate" value=""/>
					</div>
				</div>
				<div class="row">
					<label class="col">Ele deve tomar em algum dia específico?</label>
				</div>
				<div class="row">
					<div class="form-group col">
						<p>Domingo:</p>
						<select class="form-control" name="medDom">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div class="form-group col">
					<p>Segunda:</p>
						<select class="form-control" name="medSeg">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div class="form-group col">
						<p>Terça:</p>
						<select class="form-control" name="medTer">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div class="form-group col">
						<p>Quarta:</p>
						<select class="form-control" name="medQua">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div class="form-group col">
						<p>Quinta:</p>
						<select class="form-control" name="medQui">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div class="form-group col">
						<p>Sexta:</p>
						<select class="form-control" name="medSex">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div class="form-group col">
						<p>Sabádo:</p>
						<select class="form-control" name="medSab">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="form-group col">
    	    			<p>Tem um horario específico para tomar?</p>
						<input class="form-control" type="time" name="medHora" value=""/>
					</div>
				</div>
				<div class="row col">
						<p>Tem um periodo do dia específico para tomar?</p>
				</div>
				<div class="row">
					<div class="form-group col">
						<p>Manhã:</p>
						<select class="form-control" name="medPerMan">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div  class="form-group col">
						<p>Tarde:</p>
						<select class="form-control" name="medPerTar">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
					<div class="form-group col">
						<p>Noite:</p>
						<select class="form-control" name="medPerNoi">
							<option>Selecione:</option>
							<option value="Sim">Sim</option>
							<option value="Nao">Não</option>
						</select>
					</div>
				</div>
					<input class="form-control" type="submit" name="medEnviar" value="Cadastrar Medicamento"/>
</body>
</html>