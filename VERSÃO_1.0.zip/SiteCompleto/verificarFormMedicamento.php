<?php 
	$con=mysqli_connect("localhost","root","","pjenfermagem");
	if (mysqli_connect_errno())
	    {
	    	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	    }
	$dom;
	$seg;	
	$ter;	
	$qua; 
	$qui; 
	$sex; 
	$sab;	
	$manha;	
	$tarde;
	$noite;
	if(isset($_POST['paciente']))
		if(isset($_POST['medNome']))
			if(isset($_POST['medIniDate']))
			{
	$query = "INSERT INTO `medicamentos`(
	`med_pac_id`, 
	`med_nome`, 
	`med_dosagem`, 
	`med_inicio`, 
	`med_fim`, 
	`med_dom_tomar`, 
	`med_seg_tomar`, 
	`med_ter_tomar`, 
	`med_qua_tomar`, 
	`med_qui_tomar`, 
	`med_sex_tomar`, 
	`med_sab_tomar`, 
	`med_hora`, 
	`med_periodo_manha`,
	`med_periodo_tarde`,
	`med_periodo_noite`) values (
	'".$_POST["paciente"]."',
	'".$_POST["medNome"]."',
	'".$_POST["medDosagem"]."',
	'".$_POST["medIniDate"]."',
	'".$_POST["medFimDate"]."',
	'".$_POST["medDom"]."',
	'".$_POST["medSeg"]."',
	'".$_POST["medTer"]."',
	'".$_POST["medQua"]."',
	'".$_POST["medQui"]."',
	'".$_POST["medSex"]."',
	'".$_POST["medSab"]."',
	'".$_POST["medHora"]."',
	'".$_POST["medPerMan"]."',
	'".$_POST["medPerTar"]."',
	'".$_POST["medPerNoi"]."')";
		
		mysqli_query($con, $query);
			}
?>