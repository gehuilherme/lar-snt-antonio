<?php 
	$con=mysqli_connect("localhost","root","","pjenfermagem");
	if (mysqli_connect_errno())
	    {
	    	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	    }
	if(isset($_POST["relNome"]))
		if(isset($_POST["relDesc"]))
		{
			$query = "Insert into religiao(rel_nome, rel_desc) values ('".$_POST['relNome']."','".$_POST['relDesc']."')";
			mysqli_query($con, $query);
			unset($_POST);
		}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro de Pacientes - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	</head>

	<body>
		
		<?php include "menu.php"?>
		
		<header> <!-- Deixa o fundo cinza -->
			<div class="jumbotron">
				<div class="container">
					<div class="row"> <!-- Cria uma linha -->
						<div class="col-12"> <!-- Espaçamento de colunas -->
							<h1 class="text-center">Cadastro de Religião</h1>
						</div>
					</div>  
				</div>
			</div>
		</header>
	<div class="container">
		<form name="frmRel" method="post" action="" onchange="this.form.submit();">
			<div class="row">
				<div class="form-group col">
					<p>Informe o nome da religião:</p>
					<input class="form-control" type="text" name="relNome" value="<?php if(isset($_POST["relNome"])) echo $_POST["relNome"]?>">
				</div>
				<div class="form-group col">
					<p>Restrições e/ou outras informações relevantes:</p>
					<input class="form-control" name="relDesc" placeholder="Digite as informações relevantes" value="<?php if(isset($_POST["relDesc"])) echo $_POST["relNome"]?>">
				</div>
			</div>
		<input class="form-control" type="submit" name="insertRel" value="Cadastrar">
		</form>
	</div>
</body>
</html>