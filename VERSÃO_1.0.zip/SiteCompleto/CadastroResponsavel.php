<?php include "VerificarResp.php"; ?>
<?php include "DatabaseConnection.php" ?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
   <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro de Responsavel - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	</head>

	<body>
		
		<?php include "menu.php"?>
	  
		<header> <!-- Deixa o fundo cinza -->
			<div class="jumbotron">
				<div class="container">
					<div class="row"> <!-- Cria uma linha -->
						<div class="col-12"> <!-- Espaçamento de colunas -->
							<h1 class="text-center">Cadastro de Responsáveis</h1>
						</div>
					</div>  
				</div>
			</div>
		</header>
	  
	  <div class="container">
		<form method="post" name="frmResp" action="" onchange="this.form.submit();">
			<div class="form-row">
				<div class="col-2">
				<select name="paciente" class="form-control">
					<?php
					$result = mysqli_query($con,"SELECT pac_id, pac_nome, pac_sobrenome FROM paciente order by pac_nome;");
					while($row = mysqli_fetch_array($result))
					{
						echo "<option value=". $row['pac_id'] .">". $row['pac_nome'] ." ". $row['pac_sobrenome']."</option>";
					}
					?>
				</select>
				</div>
			</div>
			<br>
			<div class="form-row">
				<div class="form-group">
					<div class="col">
						<p>Nome responsavel:</p>
						<input class="form-control" type="text" name="resNome" value="<?php if(isset($_POST['resNome'])) echo $_POST['resNome']; ?>"/>
					</div>	
				</div>
				
				<div class="form-group">
					<div class="col">
						<p>Sobrenome:</p>
						<input class="form-control" type="text" name="resSobrenome" value="<?php if(isset($_POST['resSobrenome'])) echo $_POST['resSobrenome']; ?>"/>
					</div>
				</div>
				<div class="form-group">
					<div class="col">
						<p>CPF responsavel:</p>
						<input class="form-control" type="text" name="resCPF" value="<?php if(isset($_POST['resCPF'])) echo $_POST['resCPF']; ?>"/>
					</div>
				</div>
			
				<div class="form-group">
					<div class="col">
						<p>Data de nascimento</p>
						<input class="form-control" type="date" name="resDate" value="">
					</div>
				</div>
			</div>
			<br>
			<div class="form-row">
				<div class="form-group">
					<div class="col">
						<p>Estado(UF):</p>
        				<select name="resUF" class="form-control">
        					<option value="AC">Acre</option>
        					<option value="AL">Alagoas</option>
        					<option value="AP">Amapá</option>
        					<option value="AM">Amazonas</option>
        					<option value="BA">Bahia</option>
        					<option value="CE">Ceará</option>
        					<option value="DF">Distrito Federal</option>
        					<option value="ES">Espírito Santo</option>
        					<option value="GO">Goiás</option>
        					<option value="MA">Maranhão</option>
        					<option value="MT">Mato Grosso</option>
        					<option value="MS">Mato Grosso do Sul</option>
        					<option value="MG">Minas Gerais</option>
        					<option value="PA">Pará</option>
        					<option value="PB">Paraíba</option>
        					<option value="PR">Paraná</option>
        					<option value="PE">Pernambuco</option>
        					<option value="PI">Piauí</option>
        					<option value="RJ">Rio de Janeiro</option>
        					<option value="RN">Rio Grande do Norte</option>
        					<option value="RS">Rio Grande do Sul</option>
        					<option value="RO">Rondônia</option>
        					<option value="RR">Roraima</option>
        					<option value="SC">Santa Catarina</option>
        					<option value="SP">São Paulo</option>
        					<option value="SE">Sergipe</option>
        					<option value="TO">Tocantins</option>
        				</select>
				</div>
			</div>
			<div class="form-group">
				<div class="col">
					<p>Cidade:</p>
					<input class="form-control" type="text" name="resCidade" value="<?php if(isset($_POST['resCidade'])) echo $_POST['resCidade']; ?>"/>
				</div>
			</div>
			<div class="form-group">
				<div class="col">
					<p>Rua:</p>
					<input class="form-control" type="text" name="resRua" value="<?php if(isset($_POST['resRua'])) echo $_POST['resRua']; ?>"/>
				</div>
			</div>
			<div class="form-group">
				<div class="col">
					<p>Número:</p>
					<input class="form-control" type="text" name="resNum" value="<?php if(isset($_POST['resNum'])) echo $_POST['resNum']; ?>"/>
				</div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group">
				<div class="col">
				<input class="form-control btn btn-primary" type="submit" name="frmSubmit" value="Cadastrar"/>
				</div>
			</div>
		</div>	
		</form>
	</div>
    </body>
</html>