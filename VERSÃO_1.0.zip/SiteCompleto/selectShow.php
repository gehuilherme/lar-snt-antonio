<?php include "DatabaseConnection.php"; ?>
	<?php 
		$query = null;
		if(isset($_POST['paciente']))
		$query = "Select * from paciente where pac_id = ".$_POST['paciente']; 
	?>
<!doctype html>
<html>

<html>
	<head>
	<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;    
}
</style>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro Prontuario - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap-grid.css" rel="stylesheet">
		<link href="css/bootstrap-reboot.css" rel="stylesheet">
		<link href="css/bootstrap-grid.min.css" rel="stylesheet">
	</head>

	<body>
 	  <?php include "menu.php"?>

	  
    <header> <!-- Deixa o fundo cinza -->
      <div class="jumbotron">
        <div class="container">
          <div class="row"> <!-- Cria uma linha -->
            <div class="col-12"> <!-- Espaçamento de colunas -->
              <h1 class="text-center">Cadastro de Prontuário</h1>
            </div>
		  </div>  
		</div>
	  </div>
	 
	 <section>
		<div class="container">
		  <div class="form-group">
                 <div class="form-control">
</head>

<body>
	<form name="formShow" method="post" action="" onchange="this.form.submit();">
		<p>Selecione o paciente:</p>
		<select class="form-control" name="paciente">
			<option value="">Selecione o paciente:</option>
		<?php
			$result = mysqli_query($con,"SELECT pac_id, pac_nome, pac_sobrenome FROM paciente order by pac_nome;");
			while($row = mysqli_fetch_array($result))
			{
				echo "<option value=". $row['pac_id'] .">". $row['pac_nome'] ." ". $row['pac_sobrenome']."</option>";
			}
		?>
		</select>
		<input class="form-control" type="submit" name="showRefresh" value="Atualizar"/>
	</form>
	<?php 
		if($query != null)
		{
			$resultado = mysqli_query($con, $query);
			while($row = mysqli_fetch_array($resultado))
				{
				?>
				<center><h1 style="font-size:40px;">Dados Do Paciente</h1><center/>
		          <table width="103%">
                      <tr>
					<p><td>Nome: <?php echo $row['pac_nome'].' '.$row['pac_sobrenome'] ?> </td></p>
			     	<p><td>RG: <?php echo $row['pac_rg'] ?></p>
					<p><td>CPF: <?php echo $row['pac_CPF'] ?> </p>
	        		<p><td>Data de Nascimento: <?php echo $row['pac_dt_nasc'] ?> </td></p>
		        </tr>
		 <table/>
		 <table width="103%">
                   <tr>                     
					<p><td>Estado Civil: <?php echo $row['pac_est_civil'] ?> </td></p>		           
					<p><td>Data de Entrada: <?php echo $row['pac_dt_entrada'] ?></td></p> 					
				    <p><td>Sexo: <?php echo $row['pac_sexo'] ?></td></p>           			
				    <p><td>Etnia: <?php echo $row['pac_etnia'] ?></td></p>
					<p><td>Peso: <?php echo $row['pac_peso'] ?></td></p> 
			  </tr>
		<table/>
			<table width="103%">
                      <tr>
					<p><td>Altura: <?php echo $row['pac_alt'] ?></td></p>				
					<p><td>Encaminhado de Forma: <?php echo $row['pac_enc'] ?></td></p> 					
			   </tr>
	     <table/>
            <table width="103%">
                      <tr>
					<p><td>Dependencia: <?php echo $row['pac_dep'] ?></td></p> 
					<p><td>Condição de chegada: <?php echo $row['pac_chegada'] ?></td></p> 
					<p><td>Possui vicio: <?php echo $row['pac_vicio'] ?></td></p>  
					<p><td>Hipertenso: <?php echo $row['pac_hipertenso'] ?></td></p> 
					<p><td>Diabete: <?php echo $row['pac_diabete'] ?></td></p> 
				 </tr>
	    <table/>
		   <table width="103%">
                      <tr>
					<p><td>Cirurgia: <?php echo $row['pac_cirurgia'] ?></td></p> 
	  				<p><td>Possui ulcera: <?php echo $row['pac_ulcera'] ?></td></p> 
					<p><td>Se sim, Qual estágio: <?php echo $row['pac_ulceraEst'] ?></td></p> 
			<tr/>
		<table/>
			<table width="103%">
                     <tr>
					<p><td>Crise Convulsiva: <?php echo $row['pac_crise_con'] ?></td></p> 
					<p><td>Faz uso de medicamento: <?php echo $row['pac_medicamento'] ?></td></p> 
					<p><td>Alergico a medicamento: <?php echo $row['pac_alergia_med'] ?></td></p>
				</tr>
		 <table/>
			<?php
				}
		}
	?>
	
	<footer class="text-center"> <!-- Rodapé da página -->
       <div class="container">
		  <p class="mb-0">Lar Santo Antônio</p>
        <div class="row">
          <div class="col-12 blockquote-footer">
            <p>Copyright © ADS.</p>
          </div>
        </div>
      </div>
    </footer>
</body>
</html>