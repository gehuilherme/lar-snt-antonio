<?php 
    date_default_timezone_set('America/Sao_Paulo'); 
    $dataAtual = date("Y/m/d");
    $con=mysqli_connect("localhost","root","","pjenfermagem");
	if (mysqli_connect_errno())
	    {
	    	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	    }

    $selecao = "UPDATE `agenda` SET age_status = 'INATIVO' where age_dt < (SELECT NOW())";
    $query = mysqli_query($con, $selecao);

    header("LOCATION: ../index.php")
?>