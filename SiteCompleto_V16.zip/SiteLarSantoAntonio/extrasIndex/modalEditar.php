<?php 
      $con=mysqli_connect("localhost","root","","pjenfermagem");
	    if (mysqli_connect_errno())
	    {
	    	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	    }
      $querySelect = 'Select paciente.pac_id as idPaciente, paciente.pac_nome as nome, paciente.pac_sobrenome as sobrenome, agenda.age_id as idAgenda, agenda.age_camp as texto, agenda.age_dt as Data, agenda.age_hora as Hora, agenda.age_rua as Rua, agenda.age_num as Numero From agenda, paciente where agenda.age_pac_id = paciente.pac_id'
?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">

        <div class="modal-header">
          <h1>Edição de agenda</h1>
        </div>

        <div class="modal-body">
          <form action="atualizar.php">
            <select name="compSele" id="seleciaonarComp">
              <?php
                while($row = mysqli_fetch_array(mysqli_query($con,$querySelect))){
              ?>
                  <option value="<?php echo $row['idPaciente']; ?>">
                    <?php echo $row['nome'] ." ".$row['sobrenome'];?> 
                  </option>
                <?php }?>
            </select>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
