<?php include($_SERVER['DOCUMENT_ROOT']. '/SiteLarSantoAntonio/menu.php');?>
<script>
	$(document).ready(function() {
	$('#dataTabela').DataTable({			
		"processing": true,
		"serverSide": true,
		"ajax": {
			"url": "requisicaoDataTable.php",
			"type": "POST"
		}
	});
	} );
</script>
<header>
	<div class="jumbotron">
		<div class="container">
			<div class="row"> 
				<div class="col-12">
					<h1 class="text-center">Agenda de Medicamentos</h1>
				</div>
			</div>  
		</div>
	</div>
</header>
    <div id="mostrarEvento" class="container">
		<table id='dataTabela' class='display table'> 
			<thead class='thead-dark'>
				<tr>
					<th scope='col'>Nome do Paciente</th>
					<th scope='col'>Nome do Medicamento</th>
                    <th scope='col'>Dosagem</th>
					<th scope='col'>Proximo Horario</th>
                    <th scope='col'>Data Inicial</th>
                    <th scope='col'>Data Final</th>
				</tr>
			</thead>
		</table>
		<form id="UpdateTable" action="/SiteLarSantoAntonio/paginas/agendaMed/Update.php" method="post">
			<input class="btn btn-dark" type="submit" id="alterarCampos" value="Atualizar"/>
		</form>
	</div>
		<!------------------------------------------Agenda------------------------------------------->
		<!------------------------------------------Rodapé------------------------------------------->
	<footer class="text-center">
		<div class="container">
			<p class="mb-0">Lar Santo Antônio</p>
		<div class="row">
		<div class="col-12 blockquote-footer">
           <p>Copyright © ADS.</p>
		</div>
		</div>
		</div>
	</footer>
		<!------------------------------------------Rodapé------------------------------------------->
</body>
</html>