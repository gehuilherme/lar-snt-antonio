<?php 
    $con=mysqli_connect("localhost","root","","pjenfermagem");
	if (mysqli_connect_errno())
	    {
	    	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	    }

    $selecao = "UPDATE `pacmedicamentos` SET pacMed_status = 'INATIVO' where pacMed_Fim < (SELECT NOW())";
    $query = mysqli_query($con, $selecao);

    header("LOCATION: index.php")
?>