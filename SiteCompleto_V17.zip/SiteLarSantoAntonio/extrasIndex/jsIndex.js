$(document).ready(function() 
{ 
    $('#dataTabela').DataTable({			
      "processing": true,
      "serverSide": true,
      "ajax": {
        "url": "pagExtras/requisicaoDataTable.php",
        "type": "POST"
      },
    });
    /* $("#alterarCampos").click(function(){
      let frm = $('#UpdateTable'); 
    
      frm.submit(function(e){
          e.preventDefault();
          $.ajax({
              type: frm.attr('method'),
              url: frm.attr('action'),
              data: frm.serialize(),
   
  
              success: function(){
                  alert("Formulario enviado com sucesso");
                  window.location.reload();
              },
              error: function(){
                  alert("Ocorreu um erro");
                  window.location.reload();
              }
          });
      });	
      }) */
})