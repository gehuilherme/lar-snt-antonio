
		$('#DiasSemana').hide();
		//let btn1 = document.getElementById('btn11');
		$('#btn22').hide();
		$('#horaEve2').hide();
		$('#horaEve3').hide();

		
		function verifiDias(base){
			if(base.value == "Sim")
				$('#DiasSemana').show();
			else if(base.value == "Nao")
				$('#DiasSemana').hide();;
		}

		function addHoras(basement){
			if(basement == "Sim"){
				$("#horaEve2").show();
				$("#btn11").hide();
				$("#btn22").show();
			}
			else if(basement == "Sim2")
			{
				$("#horaEve3").show();
				$("#btn22").hide();
			}
		}
		function submeterNovoRegistro(id_formulario){
			let frm = $('#' + id_formulario); 
			
			frm.submit(function(e){
				e.preventDefault();
				$.ajax({
					type: frm.attr('method'),
					url: frm.attr('action'),
					data: frm.serialize(),
		 
	
					success: function(){
						alert("Formulario enviado com sucesso");
						window.location.reload();
					},
					error: function(){
						alert("Ocorreu um erro");
						window.location.reload();
					}
				});
	
			});	
		}