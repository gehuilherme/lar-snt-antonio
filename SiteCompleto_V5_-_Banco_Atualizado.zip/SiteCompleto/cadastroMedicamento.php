<?php include "verificarFormMedicamento.php"?>

<!doctype html>

<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro de Pacientes - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<title>Cadastro de Pacientes - Lar Santo Antônio</title>
    <!-- Bootstrap -->
		<link href="../css/bootstrap.css" rel="stylesheet">
	</head>

	<body>
	<!------------------------------------------Menu--------------------------------------------->
		<?php include "menu.php"?>
		<header>
			<div class="jumbotron">
				<div class="container">
					<div class="row"> 
						<div class="col-12">
							<h1 class="text-center">Cadastro de Medicamentos</h1>
						</div>
					</div>  
				</div>
			</div>
		</header>
	<!------------------------------------------Menu--------------------------------------------->
	<!------------------------------------------Cadastro----------------------------------------->
		<div class="container">
			<form method="post" name="frmMedicamento" action="" onchange="this.form.submit();">
				<!-----------------------------------Selecão de paciente--------------------------------------------->
				<select name="paciente" class="form-control">
					<option value="">Selecione:</option>
						<?php
						$result = mysqli_query($con,"SELECT pac_id, pac_nome, pac_sobrenome FROM paciente order by pac_nome;");
						while($row = mysqli_fetch_array($result))
						{
							echo "<option value=". $row['pac_id'] .">". $row['pac_nome'] ." ". $row['pac_sobrenome']."</option>";
						}
						?>
				</select>
				<!-----------------------------------Selecão de paciente--------------------------------------------->
				<!-----------------------------------Medicamento Nome e Dosagem-------------------------------------->
				<div class="form-row">
					<div class="col">
						<p>Nome do medicamento:</p>
						<input class="form-control" type="text" name="medNome" value="<?php if(isset($_POST['medNome'])) echo $_POST['medNome']?>" placeholder="Digite o nome do medicamento"/>
					</div>
					<div class="form-group col">
						<p>Dosagem do medicamento:</p>
						<input class="form-control" type="text" name="medDosagem" value="<?php if(isset($_POST['medDosagem'])) echo $_POST['medDosagem']?>" placeholder="Digite a dosagem do medicamento"/>
					</div>
					
				<!-----------------------------------Medicamento Nome e Dosagem-------------------------------------->
				<!-----------------------------------Periodo do medicamento------------------------------------------>

				</div>
				<div class="form-row">
					<div class="col">
						<p>Começou a tomar o medicamento dia:</p>
						<input class="form-control" type="date" name="medIniDate" value=""/>
					</div>
					
					<div class="col">
						<p>Tomar o medicamento até o dia:</p>
						<input class="form-control" type="date" name="medFimDate" value=""/>
					</div>
				</div>
				<!-----------------------------------Periodo do medicamento------------------------------------------>
				<!-----------------------------------Dias do medicamento------------------------------------------>
				<div class="form-row">
					<label class="col">Ele deve tomar em algum dia específico?</label>
				</div>
				<div class="form-row">
					<div class="col">
						<p>Domingo:</p>
						<select class="form-control" name="medDom">
							<option value="Domingo">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div class="col">
					<p>Segunda:</p>
						<select class="form-control" name="medSeg">
							<option value="Segunda">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div class="col">
						<p>Terça:</p>
						<select class="form-control" name="medTer">
							<option value="Terça">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div class="col">
						<p>Quarta:</p>
						<select class="form-control" name="medQua">
							<option value="Quarta">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div class="col">
						<p>Quinta:</p>
						<select class="form-control" name="medQui">
							<option value="Quinta">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div class="col">
						<p>Sexta:</p>
						<select class="form-control" name="medSex">
							<option value="Sexta">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div class="col">
						<p>Sabádo:</p>
						<select class="form-control" name="medSab">
							<option value="Sabádo">Sim</option>
							<option>Não</option>
						</select>
					</div>
				</div>
				<!-----------------------------------Dias do medicamento------------------------------------------>
				<!-----------------------------------Horario do medicamento--------------------------------------->
				<div class="form-row">
					<div class="form-group col">
    	    			<p>Tem um horario específico para tomar?</p>
						<input class="form-control" type="time" name="medHora" value=""/>
					</div>
				</div>
				<div class="form-row">
					Tem um periodo do dia específico para tomar?
				</div>
				<!-----------------------------------Horario do medicamento--------------------------------------->
				<!-----------------------------------Periodo do dia do medicamento-------------------------------->
				<div class="form-row">
					<div class="col">
						<p>Manhã:</p>
						<select class="form-control" name="medPerMan">
							<option value="Manhã">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div  class="col">
						<p>Tarde:</p>
						<select class="form-control" name="medPerTar">
							<option value="Tarde">Sim</option>
							<option>Não</option>
						</select>
					</div>
					<div class="col">
						<p>Noite:</p>
						<select class="form-control" name="medPerNoi">
							<option value="Noite">Sim</option>
							<option>Não</option>
						</select>
					</div>
				</div>
				<!-----------------------------------Periodo do dia do medicamento-------------------------------->
				<!-----------------------------------Botão-------------------------------------------------------->
				<div class="form-row">
					<div class="col-4">
					
					</div>
					<div class="col-4">
						<hr></hr>
						<center>
							<input class="btn btn-dark" type="submit" name="medEnviar" value="Cadastrar Medicamento"/>
						</center>
					</div>
					<div class="col-4">
				
					</div>
				</div>
			</form>	
				<!-----------------------------------Botão-------------------------------------------------------->
		</div>
		</br>
	<!------------------------------------------Cadastro----------------------------------------->
</body>
</html>