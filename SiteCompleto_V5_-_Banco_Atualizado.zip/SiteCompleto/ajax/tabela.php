<?php
include_once("../DatabaseConnection.php");
$return = array();
$sql= "SELECT * FROM medicamentos";
$result=mysqli_query($con,$sql);

if(mysqli_num_rows($result) >= 1){

	while($row = mysqli_fetch_array($result)){

        $id = $row['med_id'];
		$paciente = $row['med_pac_id'];
		$medicamento = $row['med_nome'];
		$dosagem = $row['med_dosagem'];
		
			$return_arr[] = array("id" => $id,
			                "paciente" => $paciente,
							"medicamento" => $medicamento,
							"dosagem" => $dosagem);
	}
	echo json_encode($return_arr);
	die();
	}else{
	$mensagem = "Tabela Vazia";
		
			$return_arr[] = array("mensagem" => $mensagem);
		
	echo json_encode($return_arr);
}

?>