<?php include "DatabaseConnection.php" ?>
<?php
	if(isset($_POST["ano_camp"]))
		{
			$query = "Insert into `anotacoes`(`ano_pac_id`, `ano_camp`, `ano_dt`) values ('".$_POST["paciente"]."','".$_POST["ano_camp"]."','".$_POST["ano_dt"]."')";
			mysqli_query($con, $query);
			unset($_POST);
		}
?>
<!doctype html>
<html>


	<head>
        <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro Prontuario - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap-grid.css" rel="stylesheet">
		<link href="css/bootstrap-reboot.css" rel="stylesheet">
		<link href="css/bootstrap-grid.min.css" rel="stylesheet">
	</head>

	<body>
		<!------------------------------------------Menu--------------------------------------------->
		<?php include "menu.php"?>
		<header> 
			<div class="jumbotron">
				<div class="container">
					<div class="row"> <!-- Cria uma linha -->
						<div class="col-12"> <!-- Espaçamento de colunas -->
							<h1 class="text-center"> Cadastro de Anotaçoes </h1>
						</div>
					</div>  
				</div>
			</div>
		</header>
		<!------------------------------------------anotacações-------------------------------------->
		<div class="container">
		   <form method="post" name="frmResp" action="" onchange="this.form.submit();">
		   		<div class="form-row">
				  <div class="col-2">
				    <p>Paciente</p>
				    <select name="paciente" class="form-control">
				    <option>Selecione:</option>
					    <?php $result = mysqli_query($con,"SELECT pac_id, pac_nome, pac_sobrenome FROM paciente order by pac_nome;");
					        while($row = mysqli_fetch_array($result)){
							    echo "<option value=". $row['pac_id'] .">". $row['pac_nome'] ." ". $row['pac_sobrenome']."</option>"; } ?>
				    </select>
				   	<p>Data</p>
					<input class="form-control" type="date" name="ano_dt" value="<?php if(isset($_POST["ano_dt"])) echo $_POST["ano_dt"]?>">
				  </div>
					<div class="form-group col">
					<p>Anotações</p>
					<input class="form-control" type="text" name="ano_camp" value="<?php if(isset($_POST["'ano_camp"])) echo $_POST["ano_camp"]?>" placeholder="Digite a anotação">
			        </div>
				</div>
				</br>

				<!-----------------------------------botão------------------------------------------>

				<div class="form-row">
					<div class="col-4">
				
					</div>
					<div class="col-4">
						<hr></hr>
						<center>
							<input class="btn btn-dark" type="submit" class="btn btn-dark" name="frmSubmit" value="Cadastrar">
						</center>
					</div>
					<div class="col-4">
				
					</div>
				</div>
				
				<!--BOTÃO ANTIGO CASO PRECISE-->
				<!--<input class="form-control" type="submit" name="frmSubmit" value="Cadastrar">-->

				<!-----------------------------------botão------------------------------------------>

		   </form>
		</div>
		<!------------------------------------------Rodapé------------------------------------------->
    </body>
</html>