<?php include "DatabaseConnection.php" ?>
<?php 
	date_default_timezone_set('America/Sao_Paulo');
	$data = date("Y-m-d");
	$result = mysqli_query($con,"select pac_nome, pac_sobrenome, age_camp, age_hora, age_dt, age_rua, age_num from agenda JOIN paciente where age_pac_id = pac_id order by age_dt,age_hora");
	$contador = mysqli_query($con, "SELECT COUNT(*) FROM agenda")
?>
<!doctype html>
<html>


	<head>
        <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro Prontuario - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap-grid.css" rel="stylesheet">
		<link href="css/bootstrap-reboot.css" rel="stylesheet">
		<link href="css/bootstrap-grid.min.css" rel="stylesheet">
	</head>

	<body>
		<!------------------------------------------Menu--------------------------------------------->
		<?php include "menu.php"?>
		<header> 
			<div class="jumbotron">
				<div class="container">
					<div class="row"> <!-- Cria uma linha -->
						<div class="col-12"> <!-- Espaçamento de colunas -->
							<h1 class="text-center"> Inicio </h1>
						</div>
					</div>  
				</div>
			</div>
		</header>
		<!------------------------------------------Menu--------------------------------------------->
		<!------------------------------------------Agenda------------------------------------------->
		<center><div id="mostrarEvento" class="container">
			<table class="table"> 
				<thead class="thead-dark">
					<tr>
						<th scope="col">Nome</th>
						<th scope="col">Compromisso</th>
						<th scope="col">Hora</th>
						<th scope="col">Data</th>
						<th scope="col">Rua</th>
						<th scope="col">Numero</th>
					</tr>
				</thead>
				
				<?php while($dado = mysqli_fetch_array($result)){
						//if($dado['age_dt'] > $date ){
				?>
				<tbody>
					<tr>
						<td><?php echo $dado['pac_nome']." ".$dado['pac_sobrenome']; ?></td>
						<td><?php echo $dado['age_camp']; ?></td>
						<td><?php echo $dado['age_hora']; ?></td>
						<td><?php echo date('d/m/Y', strtotime($dado['age_dt']));    ?></td>
						<td><?php echo $dado['age_rua'];  ?></td>
						<td><?php echo $dado['age_num'];  ?></td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
		</center>
		<!------------------------------------------Agenda------------------------------------------->
		<!------------------------------------------Rodapé------------------------------------------->
		<footer class="text-center">
			<div class="container">
				<p class="mb-0">Lar Santo Antônio</p>
			<div class="row">
			<div class="col-12 blockquote-footer">
            <p>Copyright © Unopar.</p>
			</div>
			</div>
			</div>
		</footer>
		<!------------------------------------------Rodapé------------------------------------------->
</body>
</html>