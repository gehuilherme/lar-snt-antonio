<?php 
	/*--------------------------------------------------Inserir dados Medicamentos -------------------------------------*/
	$con=mysqli_connect("localhost","root","","pjenfermagem");
	if (mysqli_connect_errno())
	    {
	    	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	    }
	$contador = 0;
	$periodoSemana;		

    if(isset($_POST["medDom"])||
	   isset($_POST["medSeg"])||
	   isset($_POST["medTer"])||
	   isset($_POST["medQua"])||
	   isset($_POST["medQui"])||
	   isset($_POST["medSex"])||
	   isset($_POST["medSab"]))
		{
			$periodoSemana = $_POST["medDom"] . "|" . 
							 $_POST["medSeg"] ."|". 
						     $_POST["medTer"] ."|". 
				             $_POST["medQua"] ."|".
						     $_POST["medQui"]."|".
							 $_POST["medSex"]."|".
							 $_POST["medSab"];
		}

	$periodoDia;
	if(isset($_POST["medPerMan"]))
	{
		$manha = $_POST["medPerMan"];
		$contador++;
	}
	if(isset($_POST["medPerTar"]))
	{
		$tarde = $_POST["medPerTar"];
		$contador++;
	}
	if(isset($_POST["medPerNoi"]))
	{
		$noite = $_POST["medPerNoi"];
		$contador++;
	}

	if($contador == 1)
	{
		$periodoDia = $_POST["medPerMan"] . $_POST["medPerTar"] . $noite = $_POST["medPerNoi"];
	}
	elseif($contador == 2)
	{ 
		if($_POST["medPerMan"] == "")
		{  
			$periodoDia = $_POST["medPerTar"] ."|". $noite = $_POST["medPerNoi"];
		}
		elseif($_POST["medPerTar"] == "")
		{
			$periodoDia = $_POST["medPerMan"] ."|". $noite = $_POST["medPerNoi"];
		}
		elseif($_POST["medPerNoi"] == "")
		{
			$periodoDia = $_POST["medPerMan"] ."|". $noite = $_POST["medPerTar"];
		}
	}
	elseif($contador == 3)
		$periodoDia = $_POST["medPerMan"] ."|". $_POST["medPerTar"] ."|". $noite = $_POST["medPerNoi"];

	if(isset($_POST['paciente']))
		if(isset($_POST['medNome']))
			if(isset($_POST['medIniDate']))
			{
				$query = "INSERT INTO `medicamentos`( 
				`med_pac_id`, 
				`med_nome`,
				`med_dosagem`, 
				`med_inicio`, 
				`med_fim`,
				`med_tomarDias`, 
				`med_hora`, 
				`med_tomarPeriodoDia`)
				VALUES (
				'".$_POST["paciente"]."',
				'".$_POST["medNome"]."',
				'".$_POST["medDosagem"]."',
				'".$_POST["medIniDate"]."',
				'".$_POST["medFimDate"]."',
				'".$periodoSemana."',
				'".$_POST["medHora"]."',
				'".$periodoDia."')";
				mysqli_query($con, $query);
			}
	/*--------------------------------------------------Inserir dados Medicamentos -------------------------------------*/
?>