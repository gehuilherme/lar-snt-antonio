<!doctype html>
<html>
<head>
<meta charset="utf-8">
		<link href="css/bootstrap.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>

<body>
		<!------------------------------------------Menu------------------------------------------->
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark"> 
			<a class="navbar-brand" href="index.php">Lar Santo Antônio</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active"> <a class="nav-link" href="index.php">Início</a> </li>
					<!------------------------------------------Cadastros------------------------------------------->
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle active" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						Cadastros
						</a>
        				<div class="dropdown-menu" aria-labelledby="navbarDropdown">
          					<a class="dropdown-item" href="cadastroPaciente.php">Cadastro de Pacientes</a>
							<a class="dropdown-item" href="CadastroResponsavel.php">Cadastro de Responsavel</a>
          					<a class="dropdown-item" href="cadastroMedicamento.php">Cadastro de Medicamentos</a>
							<a class="dropdown-item" href="registroRel.php">Cadastro de Religião</a>
							<a class="dropdown-item" href="agenda.php">Cadastro de Evento</a>
							<a class="dropdown-item" href="anotacoes.php">Adicionar Anotação</a>
							<a class="dropdown-item" href="cadastroDoencas.php">Cadastro de Doenças</a>
							<a class="dropdown-item" href="cadastroDoencaPaciente.php">Idoso Doente</a>
							<a class="dropdown-item" href="amedicamentos1.1.php">Idoso Medicamento</a>

        				</div>
      				</li>
					<!------------------------------------------Cadastros------------------------------------------->
					<!------------------------------------------Prontuarios------------------------------------------->
					<li class="nav-item dropdown">
       					<a class="nav-link dropdown-toggle active" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          				Prontuario
        				</a>
        				<div class="dropdown-menu" aria-labelledby="navbarDropdown">
          					<a class="dropdown-item" href="selectShow.php">Exibir</a>
							<a class="dropdown-item" href="trabson.php">Agenda de Medicamentos</a>
          				</div>
      				</li>
					<!------------------------------------------Prontuarios------------------------------------------->
					<li class="nav-item non-active"> <a class="nav-link" href="#">Ajuda</a> </li>
				</ul>
			</div>
		</nav>
		<!------------------------------------------Menu------------------------------------------->
</body>
</html>