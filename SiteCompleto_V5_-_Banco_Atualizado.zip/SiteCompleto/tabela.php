<?php
include_once("../../../../config.php");
$return = array();
$sql= "SELECT * FROM cpg WHERE PAGO = 'SIM'";
$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result) >= 1){

	while($row = mysqli_fetch_array($result)){

        $id = $row['ID'];
		$nome = $row['NOME'];
		$valor = $row['VALOR'];
		$data = $row['DATA'];
		$vencimento = $row['VENCIMENTO'];
		$produtos = $row['PRODUTOS'];
		
			$return_arr[] = array("id" => $id,
			                "nome" => $nome,
							"valor" => $valor,
							"data" => $data,
							"vencimento" => $vencimento,
							"produtos" => $produtos);
	}
	echo json_encode($return_arr);
	die();
	}else{
	$mensagem = "Tabela Vazia";
		
			$return_arr[] = array("mensagem" => $mensagem);
		
	echo json_encode($return_arr);
}

?>