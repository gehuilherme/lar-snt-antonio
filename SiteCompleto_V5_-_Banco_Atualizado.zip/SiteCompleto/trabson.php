<html>
<link rel="stylesheet" href="css/datatables.css">
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/main-js.js"></script>
<script src="js/datatables.min.js"></script>
<head>
<meta charset="utf-8">
<title>Tabela medicamentos</title>
</head>
<script>
$(document).ready(function(){
    $.ajax({
      url: 'ajax/tabela.php',
      success: function(data,status)
      {
		console.log(data);
        createTableByForLoop(data);
      },
	  async:   true,
      dataType: 'json'
    }); 
});
 
function createTableByForLoop(data)
{
  var eTable="<tbody>"
  for(var i=0; i<data.length;i++)
  {
    eTable += "<tr id="+data[i]['id']+">";
    eTable += "<td>"+data[i]['medicamento']+"</td>";
    eTable += "<td>"+data[i]['paciente']+"</td>";
    eTable += "<td>"+data[i]['medicamento']+"</td>";
    eTable += "<td>"+data[i]['dosagem']+"</td>";
    eTable += "</tr>";
  }
  eTable +="</tbody>";
  $("#example").append(eTable);
$('#example').dataTable({
    "language": {
        "url": "dataTables.pt.lang"
    }
});  
}
</script>
<body>
<div id="page-wrapper">
	<div class="col-lg-12">
			<h1 class="page-header">Medicamentos</h1>
	</div>
    <div id="Tabela">
        <table id="example" class="table table-bordered bordered table-striped table-condensed datatable" ui-jq="dataTable" ui-options="dataTableOpt">
        <thead>
            <tr>
                <th>Medicamento</th>
                <th>Paciente</th>
                <th>Remedio</th>
                <th>Dosagem</th>
            </tr>
        </thead>
    </table>
    </div>

</div>

</body>

</html>