<?php 
	$con=mysqli_connect("localhost","root","","pjenfermagem");
	if (mysqli_connect_errno())
	    {
	    	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	    }
	if(isset($_POST["doe_nome"]))
		if(isset($_POST["doe_obs"]))
		{
			$query = "Insert into doencas(doe_nome, doe_obs) values ('".$_POST['doe_nome']."','".$_POST['doe_obs']."')";
			mysqli_query($con, $query);
			unset($_POST);
		}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro de Doenças - Lar Santo Antônio</title>
		<link href="css/bootstrap.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	</head>

	<body>		
	<!------------------------------------------Menu------------------------------------------->
		<?php include "menu.php"?>		
		<header>
			<div class="jumbotron">
				<div class="container">
					<div class="row"> 
						<div class="col-12"> 
							<h1 class="text-center">Cadastro de Doenças</h1>
						</div>
					</div>  
				</div>
			</div>
		</header>
	<!------------------------------------------Menu------------------------------------------->
	<!------------------------------------------Informações Doença--------------------------->
	<div class="container">
		<form name="frmDoencas" method="post" action="" onchange="this.form.submit();">
			<div class="form-row">
				<div class="col">
					Nome da doença:
					<input class="form-control" type="text" placeholder="Digite o nome da doença" name="doe_nome" value="<?php if(isset($_POST["doe_nome"])) echo $_POST["doe_nome"]?>">
				</div>
				<div class="col">
					Informações sobre a doença.
					<textarea class="form-control" name="doe_obs" placeholder="Informações adicionais sobre a doença." value="<?php if(isset($_POST["doe_obs"])) echo $_POST["doe_obs"]?>"></textarea>
				</div>
			</div>
			
			<div class="form-row">
				<div class="col-4">
				
				</div>
				<div class="col-4">
					<hr></hr>
					<center>
						<input class="btn btn-dark" type="submit" name="insertDoenca" value="Cadastrar">
					</center>
				</div>
				<div class="col-4">
				
				</div>
			</div>
		
		</form>
	</div>
	<!------------------------------------------Informações Doenças--------------------------->
</body>
</html>